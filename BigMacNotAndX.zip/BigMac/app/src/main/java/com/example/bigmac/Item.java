package com.example.bigmac;

public class Item
{
    private int calories;
    private int protein;
    private int fiber;
    private int sodium;
    private int sugar;

    public int getCalories() {
        return calories;
    }

    public int getProtein() {
        return protein;
    }

    public int getFiber() {
        return fiber;
    }

    public int getSodium() {
        return sodium;
    }

    public int getSugar() {
        return sugar;
    }
}
