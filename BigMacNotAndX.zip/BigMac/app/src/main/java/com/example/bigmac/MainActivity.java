package com.example.bigmac;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.widget.Spinner;
import android.text.TextUtils;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
    private Calculator calculator = new Calculator();
    private User user = new User();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button butGetMCal = findViewById(R.id.butGetMCal);

        Spinner spinnerGender = findViewById(R.id.spinnerGender);
        ArrayAdapter<CharSequence> genderAdapter = ArrayAdapter.createFromResource(this, R.array.sArrayGenders, android.R.layout.simple_spinner_item);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGender.setAdapter((genderAdapter));
        spinnerGender.setOnItemSelectedListener(this);

        Spinner spinnerActivity = findViewById(R.id.spinnerActivity);
        ArrayAdapter<CharSequence> activityAdapter = ArrayAdapter.createFromResource(this, R.array.sArrayActivity, android.R.layout.simple_spinner_item);
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerActivity.setAdapter((activityAdapter));
        spinnerActivity.setOnItemSelectedListener(this);
    }

    public void OnBtnGetMCalClick(View view)
    {
        EditText edtTxtAge = findViewById(R.id.edtTxtAge);
        EditText edtTxtHeight = findViewById(R.id.edtTxtHeight);
        EditText edtTxtWeight = findViewById(R.id.edtTxtWeight);

        if (    TextUtils.isDigitsOnly(edtTxtAge.getText().toString())
                && TextUtils.isDigitsOnly(edtTxtHeight.getText().toString())
                && TextUtils.isDigitsOnly(edtTxtWeight.getText().toString())
                && (user.getGender() == 0 || user.getGender() == 1)
        )
        {
            int age = Integer.valueOf(edtTxtAge.getText().toString());
            int height = Integer.valueOf(edtTxtHeight.getText().toString());
            int weight = Integer.valueOf(edtTxtWeight.getText().toString());

            int mCal = calculator.CalculateMCal(age, height, weight, user.getGender(), user.getActivity());
            TextView txtMCal = findViewById(R.id.txtMCal);
            txtMCal.setText(Integer.toString(mCal));
        }

        else
        {
            return;
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {
        switch (parent.getId())
        {
            case R.id.spinnerGender:
                if (position == 0) user.setGender(0);
                else user.setGender(1);;
                break;

            case R.id.spinnerActivity:
                switch(position)
                {
                    case 0: user.setActivity(0); break;
                    case 1: user.setActivity(1); break;
                    case 2: user.setActivity(2); break;
                    case 3: user.setActivity(3); break;
                    case 4: user.setActivity(4); break;
                }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent)
    {

    }
}