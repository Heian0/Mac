package com.example.bigmac;

import android.support.annotation.MenuRes;
import android.support.annotation.NonNull;

import androidx.fragment.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

public class vpMenuAdapter extends FragmentPagerAdapter
{
    private final ArrayList<Fragment> fragmentList = new ArrayList<>();
    private final ArrayList<String> fragNameList =  new ArrayList<>();

    public vpMenuAdapter(@NonNull FragmentManager fm, int behaviour)
    {
        super(fm, behaviour);
    }

    @NonNull
    @Override
    public Fragment getItem(int pos) {
        return fragmentList.get(pos);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }
}
